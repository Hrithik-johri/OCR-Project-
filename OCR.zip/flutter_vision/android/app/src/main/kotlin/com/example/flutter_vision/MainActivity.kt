package com.example.flutter_vision

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
